"""
ChessGym Position Scanner
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Scans PGN databases to find winning positions for training.
Uses a single ScannerInput/ folder with rotating eval ranges.

Per-game tracking:
  "found"      - position extracted, never reprocess
  "skip_range1" - checked for +2 to +3, nothing found
  "skip_range2" - checked for +1 to +2, nothing found
  "skip_range3" - checked for +0.7 to +1, nothing found
A game is fully done when "found" OR all three skip flags set.

Rotation: searches for range 1 first. On match, rotates to range 2,
then range 3, then back to range 1. Unmatched games stay available
for other ranges.

Usage:
  python position_scanner.py              - scan with rotation
  python position_scanner.py --stats      - show position counts
  python position_scanner.py --reset      - clear everything and rescan

Install: py -m pip install python-chess
"""

import os, sys, json, hashlib, subprocess, time, shutil
import chess, chess.engine, chess.pgn

# -- Paths -------------------------------------------------------------------
if getattr(sys, 'frozen', False):
    HERE = getattr(sys, '_MEIPASS', os.path.dirname(sys.executable))
else:
    HERE = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(HERE, "ScannerInput")
PROGRESS_FILE = os.path.join(HERE, "scanner_progress.json")

MIN_MOVE = 10
DEPTH = 15
MIN_ELO = 2550

RANGES = [
    {
        "label": "+2 to +3", "skip_key": "skip_range1",
        "w_dir": os.path.join(HERE, "WPlusTwoAdv"),
        "b_dir": os.path.join(HERE, "BPlusTwoAdv"),
        "w_min": 2.0, "w_max": 3.0,
    },
    {
        "label": "+1 to +2", "skip_key": "skip_range2",
        "w_dir": os.path.join(HERE, "WPlusOneAdv"),
        "b_dir": os.path.join(HERE, "BPlusOneAdv"),
        "w_min": 1.0, "w_max": 2.0,
    },
    {
        "label": "+0.7 to +1", "skip_key": "skip_range3",
        "w_dir": os.path.join(HERE, "WPlusSmallAdv"),
        "b_dir": os.path.join(HERE, "BPlusSmallAdv"),
        "w_min": 0.7, "w_max": 1.0,
    },
]
ALL_SKIP_KEYS = [r["skip_key"] for r in RANGES]

# -- Stockfish finder --------------------------------------------------------
def find_stockfish():
    import shutil
    here = HERE
    cwd = os.getcwd()
    resource_dir = getattr(sys, '_MEIPASS', here)
    candidates = [
        os.path.join(resource_dir, "stockfish", "stockfish.exe"),
        os.path.join(resource_dir, "stockfish", "stockfish"),
        os.path.join(here, "stockfish", "stockfish.exe"),
        os.path.join(here, "stockfish", "stockfish"),
        os.path.join(here, "stockfish.exe"), os.path.join(here, "stockfish"),
        os.path.join(cwd, "stockfish", "stockfish.exe"),
        os.path.join(cwd, "stockfish.exe"), os.path.join(cwd, "stockfish"),
        os.path.abspath("stockfish.exe"), os.path.abspath("stockfish"),
    ]
    sf = shutil.which("stockfish") or shutil.which("stockfish.exe")
    if sf:
        candidates.insert(0, sf)
    for p in candidates:
        if os.path.isfile(p):
            return p
    return None

# -- Game fingerprint --------------------------------------------------------
def game_fingerprint(game):
    moves = []
    node = game
    while node.variations:
        node = node.variations[0]
        moves.append(node.move.uci())
    w = game.headers.get("White", "")
    b = game.headers.get("Black", "")
    d = game.headers.get("Date", "")
    key = f"{w}|{b}|{d}|{','.join(moves)}"
    return hashlib.md5(key.encode()).hexdigest()

# -- Progress tracking -------------------------------------------------------
# Progress format:
#   {
#     "games": { "fp_hash": ["found"] or ["skip_range1", "skip_range2"], ... },
#     "range_idx": 0,
#     "bad_elo": ["fp1", "fp2", ...]   # permanently skipped (Elo filter)
#   }

def load_progress():
    if os.path.isfile(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            data = json.load(f)
        # Migrate from old format (list of scanned fingerprints)
        if "scanned" in data and "games" not in data:
            games = {}
            for fp in data["scanned"]:
                games[fp] = ["found"]
            return {"games": games, "range_idx": data.get("range_idx", 0), "bad_elo": []}
        if "games" not in data:
            data["games"] = {}
        if "bad_elo" not in data:
            data["bad_elo"] = []
        return data
    return {"games": {}, "range_idx": 0, "bad_elo": []}

def save_progress(progress):
    with open(PROGRESS_FILE, "w") as f:
        json.dump(progress, f)

def is_game_done(flags):
    """A game is done if 'found' or all three skip flags are set."""
    if "found" in flags:
        return True
    return all(sk in flags for sk in ALL_SKIP_KEYS)

def game_needs_range(flags, range_idx):
    """Check if this game still needs to be checked for the given range."""
    if "found" in flags:
        return False
    return RANGES[range_idx]["skip_key"] not in flags

# -- Position output ---------------------------------------------------------
def append_position(pgn_path, fen, white_name, black_name, player_color):
    if player_color == "white":
        you_label, bot_label = "You", "Stockfish"
    else:
        you_label, bot_label = "Stockfish", "You"

    entry = (
        f'[Event "Winning Position"]\n'
        f'[Site "From: {white_name} vs {black_name}"]\n'
        f'[White "{you_label if player_color == "white" else bot_label}"]\n'
        f'[Black "{bot_label if player_color == "white" else you_label}"]\n'
        f'[FEN "{fen}"]\n'
        f'[SetUp "1"]\n'
        f'[Result "*"]\n'
        f'\n*\n\n'
    )
    with open(pgn_path, "a") as f:
        f.write(entry)

# -- Stats -------------------------------------------------------------------
def count_positions(pgn_path):
    if not os.path.isfile(pgn_path):
        return 0
    count = 0
    with open(pgn_path, "r") as f:
        for line in f:
            if line.strip().startswith('[Event "Winning Position"]'):
                count += 1
    return count

def show_stats():
    grand_total = 0
    for r in RANGES:
        w_pgn = os.path.join(r["w_dir"], "positions.pgn")
        b_pgn = os.path.join(r["b_dir"], "positions.pgn")
        w = count_positions(w_pgn)
        b = count_positions(b_pgn)
        print(f"\n--- {r['label']} range ---")
        print(f"  White positions: {w}")
        print(f"  Black positions: {b}")
        print(f"  Total: {w + b}")
        grand_total += w + b
    progress = load_progress()
    games = progress["games"]
    found_count = sum(1 for f in games.values() if "found" in f)
    done_count = sum(1 for f in games.values() if is_game_done(f))
    bad_elo = len(progress.get("bad_elo", []))
    print(f"\nGrand total: {grand_total} positions")
    print(f"Games with position extracted: {found_count}")
    print(f"Games fully done (found or all ranges checked): {done_count}")
    print(f"Games skipped (Elo filter): {bad_elo}")
    print(f"Current rotation: searching {RANGES[progress.get('range_idx', 0)]['label']}")

# -- Analyze a game for a specific range ------------------------------------
def analyze_game_for_range(game, engine, r):
    """Try to find a position in the given eval range. Returns True if found."""
    w_min, w_max = r["w_min"], r["w_max"]
    b_min, b_max = -w_max, -w_min
    w_pgn = os.path.join(r["w_dir"], "positions.pgn")
    b_pgn = os.path.join(r["b_dir"], "positions.pgn")

    white_name = game.headers.get("White", "?")
    black_name = game.headers.get("Black", "?")

    board = game.board()
    node = game
    found = False

    while node.variations and not found:
        node = node.variations[0]
        board.push(node.move)
        move_num = board.fullmove_number

        if move_num < MIN_MOVE:
            continue

        try:
            info = engine.analyse(board, chess.engine.Limit(depth=DEPTH))
            score = info["score"].white()

            if score.is_mate():
                cp = 10000 if score.mate() > 0 else -10000
            else:
                cp = score.score()

            if cp is None:
                continue

            eval_pawns = cp / 100.0

            if w_min <= eval_pawns <= w_max and board.turn == chess.WHITE:
                append_position(w_pgn, board.fen(), white_name, black_name, "white")
                found = True
                break

            if b_min <= eval_pawns <= b_max and board.turn == chess.BLACK:
                append_position(b_pgn, board.fen(), white_name, black_name, "black")
                found = True
                break

        except Exception as e:
            print(f"  Analysis error at move {move_num}: {e}")
            continue

    return found

# -- Main scan with rotation ------------------------------------------------
def scan():
    os.makedirs(INPUT_DIR, exist_ok=True)
    for r in RANGES:
        os.makedirs(r["w_dir"], exist_ok=True)
        os.makedirs(r["b_dir"], exist_ok=True)

    # Find PGN files
    pgn_files = []
    for fname in sorted(os.listdir(INPUT_DIR)):
        if fname.lower().endswith(".pgn"):
            pgn_files.append(os.path.join(INPUT_DIR, fname))

    if not pgn_files:
        print(f"No PGN files found in {INPUT_DIR}/")
        print("Place your PGN database files there and run again.")
        return

    # Find Stockfish
    sf_path = find_stockfish()
    if sf_path is None:
        print("ERROR: stockfish.exe not found!")
        print("Place stockfish.exe in the same folder as this script.")
        return

    # Load progress
    progress = load_progress()
    games_db = progress["games"]       # {fp: [flags]}
    bad_elo = set(progress.get("bad_elo", []))
    range_idx = progress.get("range_idx", 0)

    # Read all games into memory
    print("Reading games...")
    all_games = []  # [(fp, game), ...]
    total_in_files = 0
    for pgn_path in pgn_files:
        fname = os.path.basename(pgn_path)
        file_count = 0
        with open(pgn_path, encoding="utf-8", errors="replace") as f:
            while True:
                game = chess.pgn.read_game(f)
                if game is None:
                    break
                total_in_files += 1
                fp = game_fingerprint(game)

                # Skip bad Elo games permanently
                if fp in bad_elo:
                    continue

                # Skip fully done games
                if fp in games_db and is_game_done(games_db[fp]):
                    continue

                # Elo filter for new games
                if fp not in games_db:
                    try:
                        w_elo = int(game.headers.get("WhiteElo", ""))
                        b_elo = int(game.headers.get("BlackElo", ""))
                    except (ValueError, TypeError):
                        bad_elo.add(fp)
                        continue
                    if w_elo < MIN_ELO or b_elo < MIN_ELO:
                        bad_elo.add(fp)
                        continue

                # Strip comments and NAGs
                node_iter = game
                while True:
                    node_iter.comment = ""
                    node_iter.nags = set()
                    if node_iter.variations:
                        node_iter = node_iter.variations[0]
                    else:
                        break

                all_games.append((fp, game))
                file_count += 1
        print(f"  {fname}: {file_count} eligible games")

    print(f"Total games in files: {total_in_files}")
    print(f"Eligible for scanning: {len(all_games)}")

    if not all_games:
        print("No new games to scan.")
        progress["bad_elo"] = list(bad_elo)
        save_progress(progress)
        return

    # Start engine
    print(f"\nStarting Stockfish: {sf_path}")
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    engine = chess.engine.SimpleEngine.popen_uci(sf_path, startupinfo=si)
    engine.configure({"Threads": 6, "Hash": 1024})
    print("Engine ready.\n")

    # Position counts
    counts = {}
    for i, r in enumerate(RANGES):
        w_pgn = os.path.join(r["w_dir"], "positions.pgn")
        b_pgn = os.path.join(r["b_dir"], "positions.pgn")
        counts[i] = {"w": count_positions(w_pgn), "b": count_positions(b_pgn)}

    analyzed = 0
    found_total = 0
    start_time = time.time()

    try:
        # Keep looping until no progress can be made
        made_progress = True
        while made_progress:
            made_progress = False

            for fp, game in all_games:
                # Skip if done or already checked for current range
                flags = games_db.get(fp, [])
                if not game_needs_range(flags, range_idx):
                    continue

                # Analyze this game for the current range
                r = RANGES[range_idx]
                analyzed += 1
                elapsed = time.time() - start_time
                rate = analyzed / elapsed if elapsed > 0 else 0
                total_found = sum(c["w"] + c["b"] for c in counts.values())
                print(f"\rSearching {r['label']}... analyzed {analyzed} | "
                      f"found {total_found} total | "
                      f"{rate:.1f} games/s", end="", flush=True)

                found = analyze_game_for_range(game, engine, r)

                if found:
                    # Mark as found — never reprocess
                    games_db[fp] = ["found"]
                    found_total += 1
                    made_progress = True

                    # Update counts
                    ri = range_idx
                    w_pgn = os.path.join(r["w_dir"], "positions.pgn")
                    b_pgn = os.path.join(r["b_dir"], "positions.pgn")
                    counts[ri]["w"] = count_positions(w_pgn)
                    counts[ri]["b"] = count_positions(b_pgn)

                    # Rotate to next range
                    range_idx = (range_idx + 1) % len(RANGES)

                    # Save periodically
                    if found_total % 10 == 0:
                        progress["games"] = games_db
                        progress["range_idx"] = range_idx
                        progress["bad_elo"] = list(bad_elo)
                        save_progress(progress)
                else:
                    # Mark skip for this range only
                    if fp not in games_db:
                        games_db[fp] = []
                    games_db[fp].append(r["skip_key"])
                    made_progress = True  # state changed, other ranges may still match

                    # Save periodically
                    if analyzed % 50 == 0:
                        progress["games"] = games_db
                        progress["range_idx"] = range_idx
                        progress["bad_elo"] = list(bad_elo)
                        save_progress(progress)

    except KeyboardInterrupt:
        print("\n\nInterrupted by user.")
    finally:
        progress["games"] = games_db
        progress["range_idx"] = range_idx
        progress["bad_elo"] = list(bad_elo)
        save_progress(progress)
        engine.quit()

    elapsed = time.time() - start_time
    print(f"\n\nDone! Analyzed {analyzed} games, found {found_total} positions in {elapsed:.1f}s")
    for i, r in enumerate(RANGES):
        print(f"  {r['label']}: White {counts[i]['w']} | Black {counts[i]['b']}")

# -- GUI-callable scan -------------------------------------------------------
def get_position_counts():
    """Return dict {range_idx: {"w": N, "b": N}} for all ranges."""
    counts = {}
    for i, r in enumerate(RANGES):
        w_pgn = os.path.join(r["w_dir"], "positions.pgn")
        b_pgn = os.path.join(r["b_dir"], "positions.pgn")
        counts[i] = {"w": count_positions(w_pgn), "b": count_positions(b_pgn)}
    return counts

def list_pgn_files():
    """Return list of PGN filenames in ScannerInput/."""
    os.makedirs(INPUT_DIR, exist_ok=True)
    return [f for f in sorted(os.listdir(INPUT_DIR)) if f.lower().endswith(".pgn")]

def add_pgn_file(src_path):
    """Copy a PGN file into ScannerInput/. Returns the destination filename."""
    os.makedirs(INPUT_DIR, exist_ok=True)
    fname = os.path.basename(src_path)
    dst = os.path.join(INPUT_DIR, fname)
    if os.path.abspath(src_path) != os.path.abspath(dst):
        shutil.copy2(src_path, dst)
    return fname

def remove_pgn_file(fname):
    """Remove a PGN file from ScannerInput/. Returns True if deleted."""
    path = os.path.join(INPUT_DIR, fname)
    try:
        if os.path.isfile(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False

def scan_for_gui(stop_event, progress_callback=None):
    """
    Run the scanning loop for GUI integration.

    stop_event:  threading.Event – set to stop scanning gracefully.
    progress_callback: callable(info_dict) called periodically with:
        {
            "status": str,          # human-readable status line
            "game_num": int,        # current game number (1-based)
            "total_games": int,     # total eligible games
            "counts": {idx: {"w": N, "b": N}},
            "analyzed": int,
            "found": int,
            "done": bool,           # True when scanning finished
            "error": str or None,
        }
    """
    def _cb(info):
        if progress_callback:
            progress_callback(info)

    os.makedirs(INPUT_DIR, exist_ok=True)
    for r in RANGES:
        os.makedirs(r["w_dir"], exist_ok=True)
        os.makedirs(r["b_dir"], exist_ok=True)

    # Find PGN files
    pgn_files = []
    for fname in sorted(os.listdir(INPUT_DIR)):
        if fname.lower().endswith(".pgn"):
            pgn_files.append(os.path.join(INPUT_DIR, fname))

    if not pgn_files:
        _cb({"status": "No PGN files found in ScannerInput/", "game_num": 0,
             "total_games": 0, "counts": get_position_counts(),
             "analyzed": 0, "found": 0, "done": True, "error": "No PGN files"})
        return

    sf_path = find_stockfish()
    if sf_path is None:
        _cb({"status": "stockfish.exe not found!", "game_num": 0,
             "total_games": 0, "counts": get_position_counts(),
             "analyzed": 0, "found": 0, "done": True, "error": "No Stockfish"})
        return

    # Load progress
    progress = load_progress()
    games_db = progress["games"]
    bad_elo = set(progress.get("bad_elo", []))
    range_idx = progress.get("range_idx", 0)

    # Read all games
    _cb({"status": "Reading PGN files...", "game_num": 0, "total_games": 0,
         "counts": get_position_counts(), "analyzed": 0, "found": 0,
         "done": False, "error": None})

    all_games = []
    total_in_files = 0
    for pgn_path in pgn_files:
        if stop_event.is_set():
            break
        with open(pgn_path, encoding="utf-8", errors="replace") as f:
            while True:
                if stop_event.is_set():
                    break
                game = chess.pgn.read_game(f)
                if game is None:
                    break
                total_in_files += 1
                fp = game_fingerprint(game)
                if fp in bad_elo:
                    continue
                if fp in games_db and is_game_done(games_db[fp]):
                    continue
                if fp not in games_db:
                    try:
                        w_elo = int(game.headers.get("WhiteElo", ""))
                        b_elo = int(game.headers.get("BlackElo", ""))
                    except (ValueError, TypeError):
                        bad_elo.add(fp)
                        continue
                    if w_elo < MIN_ELO or b_elo < MIN_ELO:
                        bad_elo.add(fp)
                        continue
                # Strip comments and NAGs
                node_iter = game
                while True:
                    node_iter.comment = ""
                    node_iter.nags = set()
                    if node_iter.variations:
                        node_iter = node_iter.variations[0]
                    else:
                        break
                all_games.append((fp, game))

    if stop_event.is_set():
        progress["bad_elo"] = list(bad_elo)
        save_progress(progress)
        _cb({"status": "Stopped.", "game_num": 0, "total_games": len(all_games),
             "counts": get_position_counts(), "analyzed": 0, "found": 0,
             "done": True, "error": None})
        return

    total_eligible = len(all_games)
    if not all_games:
        progress["bad_elo"] = list(bad_elo)
        save_progress(progress)
        _cb({"status": "No new games to scan.", "game_num": 0,
             "total_games": 0, "counts": get_position_counts(),
             "analyzed": 0, "found": 0, "done": True, "error": None})
        return

    # Start engine
    _cb({"status": "Starting Stockfish...", "game_num": 0,
         "total_games": total_eligible, "counts": get_position_counts(),
         "analyzed": 0, "found": 0, "done": False, "error": None})

    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    engine = chess.engine.SimpleEngine.popen_uci(sf_path, startupinfo=si)
    engine.configure({"Threads": 6, "Hash": 1024})

    counts = get_position_counts()
    analyzed = 0
    found_total = 0
    game_num = 0

    try:
        made_progress = True
        while made_progress and not stop_event.is_set():
            made_progress = False

            for fp, game in all_games:
                if stop_event.is_set():
                    break

                flags = games_db.get(fp, [])
                if not game_needs_range(flags, range_idx):
                    continue

                r = RANGES[range_idx]
                analyzed += 1
                game_num += 1

                # Build status string
                c = counts
                status = (f"Scanning game {game_num} of {total_eligible}... "
                          f"+2to+3: {c[0]['w']+c[0]['b']} | "
                          f"+1to+2: {c[1]['w']+c[1]['b']} | "
                          f"+0.7to+1: {c[2]['w']+c[2]['b']}")
                _cb({"status": status, "game_num": game_num,
                     "total_games": total_eligible, "counts": dict(counts),
                     "analyzed": analyzed, "found": found_total,
                     "done": False, "error": None})

                found = analyze_game_for_range(game, engine, r)

                if found:
                    games_db[fp] = ["found"]
                    found_total += 1
                    made_progress = True
                    range_idx = (range_idx + 1) % len(RANGES)
                    counts = get_position_counts()

                    if found_total % 10 == 0:
                        progress["games"] = games_db
                        progress["range_idx"] = range_idx
                        progress["bad_elo"] = list(bad_elo)
                        save_progress(progress)
                else:
                    if fp not in games_db:
                        games_db[fp] = []
                    games_db[fp].append(r["skip_key"])
                    made_progress = True

                    if analyzed % 50 == 0:
                        progress["games"] = games_db
                        progress["range_idx"] = range_idx
                        progress["bad_elo"] = list(bad_elo)
                        save_progress(progress)

    finally:
        progress["games"] = games_db
        progress["range_idx"] = range_idx
        progress["bad_elo"] = list(bad_elo)
        save_progress(progress)
        engine.quit()

    counts = get_position_counts()
    status = "Stopped." if stop_event.is_set() else "Scanning complete!"
    _cb({"status": status, "game_num": game_num,
         "total_games": total_eligible, "counts": counts,
         "analyzed": analyzed, "found": found_total,
         "done": True, "error": None})


# -- CLI ---------------------------------------------------------------------
def main():
    os.chdir(HERE)

    if "--stats" in sys.argv:
        show_stats()
    elif "--reset" in sys.argv:
        if os.path.isfile(PROGRESS_FILE):
            os.remove(PROGRESS_FILE)
            print("Progress cleared.")
        for r in RANGES:
            w_pgn = os.path.join(r["w_dir"], "positions.pgn")
            b_pgn = os.path.join(r["b_dir"], "positions.pgn")
            if os.path.isfile(w_pgn):
                os.remove(w_pgn)
                print(f"Removed {w_pgn}")
            if os.path.isfile(b_pgn):
                os.remove(b_pgn)
                print(f"Removed {b_pgn}")
        print("Reset complete. Run again without --reset to rescan.")
    else:
        scan()

if __name__ == "__main__":
    main()
