"""
svg_loader.py — Render chess piece SVGs using PyQt6's QSvgRenderer.
HD-quality vector rendering at any size. Replaces the old pycairo+lxml approach.
"""

from PyQt6.QtSvg import QSvgRenderer
from PyQt6.QtGui import QPixmap, QPainter, QImage
from PyQt6.QtCore import Qt, QRectF


def svg_to_qpixmap(svg_path: str, size: int) -> QPixmap:
    """
    Render *svg_path* to a QPixmap of *size* x *size* pixels.
    Returns an empty QPixmap on failure.
    """
    try:
        renderer = QSvgRenderer(svg_path)
        if not renderer.isValid():
            print(f"svg_loader: invalid SVG {svg_path}")
            return QPixmap()
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        renderer.render(painter, QRectF(0, 0, size, size))
        painter.end()
        return pixmap
    except Exception as e:
        print(f"svg_loader: render error {svg_path}: {e}")
        return QPixmap()


def svg_to_pil(svg_path: str, size: int):
    """
    Render SVG to a PIL Image (backward compatibility).
    Returns None on failure. Requires Pillow to be installed.
    """
    try:
        from PIL import Image
        pixmap = svg_to_qpixmap(svg_path, size)
        if pixmap.isNull():
            return None
        image = pixmap.toImage().convertToFormat(QImage.Format.Format_RGBA8888)
        ptr = image.bits()
        ptr.setsize(image.sizeInBytes())
        return Image.frombytes('RGBA', (size, size), bytes(ptr))
    except Exception:
        return None
