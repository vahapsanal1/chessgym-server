"""
ChessGym External Updater
-------------------------
Launched by ChessGym after downloading an update ZIP.
Runs independently so the main EXE is not locked.

Usage:
    updater.exe <zip_path> <install_path> <exe_name> <new_version>
"""

import sys
import os
import time
import shutil
import zipfile
import json
import subprocess

PRESERVE_FILES = {"chessgym_config.json", "chessgym_errors.log"}
PRESERVE_EXTS = {".pgn"}
LOG_PREFIX = "[Updater]"


def log(msg):
    print(f"{LOG_PREFIX} {msg}", flush=True)


def should_preserve(filename):
    if filename in PRESERVE_FILES:
        return True
    _, ext = os.path.splitext(filename)
    if ext.lower() in PRESERVE_EXTS:
        return True
    return False


def main():
    if len(sys.argv) < 5:
        log("ERROR: Expected arguments: <zip_path> <install_path> <exe_name> <new_version>")
        input("Press Enter to close...")
        sys.exit(1)

    zip_path = sys.argv[1]
    install_path = sys.argv[2]
    exe_name = sys.argv[3]
    new_version = sys.argv[4]

    log(f"ZIP:          {zip_path}")
    log(f"Install path: {install_path}")
    log(f"EXE name:     {exe_name}")
    log(f"New version:  {new_version}")

    # --- Wait for ChessGym to close ---
    log("Waiting for ChessGym to close...")
    time.sleep(2)

    # --- Verify ZIP exists and is valid ---
    if not os.path.isfile(zip_path):
        log(f"ERROR: ZIP file not found: {zip_path}")
        input("Press Enter to close...")
        sys.exit(1)

    log(f"ZIP file size: {os.path.getsize(zip_path)} bytes")
    with open(zip_path, "rb") as f:
        head = f.read(200)
    log(f"First 200 bytes text: {head.decode('utf-8', errors='replace')}")
    log(f"First 4 bytes hex: {head[:4].hex()}")

    if not zipfile.is_zipfile(zip_path):
        log("ERROR: File is not a valid ZIP archive")
        try:
            os.remove(zip_path)
        except Exception:
            pass
        input("Press Enter to close...")
        sys.exit(1)

    # --- Extract to temp folder ---
    tmp_extract = os.path.join(os.path.dirname(zip_path), "ChessGym_update_extract")
    if os.path.exists(tmp_extract):
        shutil.rmtree(tmp_extract)

    log("Extracting ZIP...")
    log(f"ZIP file size: {os.path.getsize(zip_path)} bytes")
    with open(zip_path, "rb") as f:
        head = f.read(300)
    log(f"First 4 bytes hex: {head[:4].hex()}")
    log(f"First 300 bytes text: {head.decode('utf-8', errors='replace')}")
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(tmp_extract)
    except Exception as e:
        log(f"ERROR: Failed to extract ZIP: {e}")
        input("Press Enter to close...")
        sys.exit(1)

    # Find source root — ZIP may have a single top-level folder
    entries = os.listdir(tmp_extract)
    src_root = tmp_extract
    if len(entries) == 1:
        candidate = os.path.join(tmp_extract, entries[0])
        if os.path.isdir(candidate):
            src_root = candidate

    # --- Copy files to install path ---
    log("Installing files...")
    copied = 0
    failed = []
    for dirpath, dirnames, filenames in os.walk(src_root):
        rel_dir = os.path.relpath(dirpath, src_root)
        dest_dir = os.path.join(install_path, rel_dir) if rel_dir != "." else install_path

        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir, exist_ok=True)

        for fn in filenames:
            if should_preserve(fn):
                log(f"  Preserved: {fn}")
                continue
            src_file = os.path.join(dirpath, fn)
            dst_file = os.path.join(dest_dir, fn)
            try:
                shutil.copy2(src_file, dst_file)
                copied += 1
            except Exception as e:
                rel_path = os.path.relpath(src_file, src_root)
                failed.append(rel_path)
                log(f"  FAILED: {rel_path} -> {e}")

    log(f"Copied {copied} files, {len(failed)} failed")

    if copied == 0:
        log("ERROR: No files were copied — update may be corrupt.")
        input("Press Enter to close...")
        sys.exit(1)

    # --- Update version in config ---
    config_path = os.path.join(install_path, "chessgym_config.json")
    try:
        cfg = {}
        if os.path.isfile(config_path):
            with open(config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
        cfg["version"] = new_version
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        log(f"Config version updated to: {new_version}")
    except Exception as e:
        log(f"WARNING: Could not update config version: {e}")

    # --- Cleanup temp files ---
    log("Cleaning up...")
    try:
        shutil.rmtree(tmp_extract)
    except Exception:
        pass
    try:
        os.remove(zip_path)
    except Exception:
        pass

    # --- Launch ChessGym ---
    exe_path = os.path.join(install_path, exe_name)
    log(f"Launching {exe_path}...")
    if os.path.isfile(exe_path):
        subprocess.Popen([exe_path])
    else:
        log(f"WARNING: EXE not found at {exe_path}")

    log("Update complete!")
    time.sleep(1)


if __name__ == "__main__":
    main()
